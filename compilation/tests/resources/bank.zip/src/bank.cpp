/**
 * @brief Contains a simple bank example.
 *
 * A file containing a simple bank example.
 *
 * @file      bank.cpp
 * @author    Jan Fiedor (fiedorjan@centrum.cz)
 * @date      Created 2012-01-23
 * @date      Last Update 2012-01-23
 * @version   0.1
 */

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include <iostream>

#define ACCOUNTS 5
#define WITHOUT_DATARACE false

class Account;

class Bank
{
  public:
    static int ms_bankTotal;
    static Account ms_accounts[ACCOUNTS];
    static pthread_t ms_threads[ACCOUNTS];
    static pthread_mutex_t ms_mutex;
  public:
    static void serviceNoSync(int id, int sum);
    static void serviceSynced(int id, int sum);
};

class Account
{
  public:
    static const int MAX_SUM = 100;
  public:
    int m_id;
    int m_balance;
    bool m_synchronized;
  private:
    unsigned int m_seed;
  public:
    Account() : m_id(0), m_balance(0), m_synchronized(true) {}
    Account(int id, bool synchronized) : m_id(id), m_balance(0),
      m_synchronized(synchronized)
    {
      int err;
      struct timeval tval;

      if ((err = gettimeofday(&tval, NULL)) != 0)
      {
        fprintf(stderr, "Account::Account(): gettimeofday() error %d\n", err);
        exit(EXIT_FAILURE);
      }

      m_seed = (unsigned int)tval.tv_usec;
    }
  public:
    void action()
    {
      if (m_synchronized)
        Bank::serviceSynced(m_id, rand_r(&m_seed) % MAX_SUM);
      else
        Bank::serviceNoSync(m_id, rand_r(&m_seed) % MAX_SUM);
    }
};

int Bank::ms_bankTotal = 0;
Account Bank::ms_accounts[ACCOUNTS];
pthread_t Bank::ms_threads[ACCOUNTS];
pthread_mutex_t Bank::ms_mutex;

#include <stdlib.h>
#include <execinfo.h>

void Bank::serviceNoSync(int id, int sum)
{
  ms_accounts[id].m_balance += sum;
  ms_bankTotal += sum;
}

void Bank::serviceSynced(int id, int sum)
{
  if (pthread_mutex_lock(&ms_mutex) != 0)
  {
    perror("pthread_mutex_lock: Can't lock Bank::ms_mutex!\n");
    exit(EXIT_FAILURE);
  }

  ms_accounts[id].m_balance += sum;
  ms_bankTotal += sum;

  if (pthread_mutex_unlock(&ms_mutex) != 0)
  {
    perror("pthread_mutex_unlock: Can't unlock Bank::ms_mutex!\n");
    exit(EXIT_FAILURE);
  }
}

std::ostream& operator<<(std::ostream& s, const Account& value)
{
  s << "Account(id=" << value.m_id << ",balance=" << value.m_balance
    << ",synchronized=" << value.m_synchronized << ")";
  return s;
}

void* tmain(void* arg)
{
  Account* account = static_cast< Account* >(arg);

  int loop = 5;

  for(int i = 0; i< loop; i++)
  {
    account->action();

    struct timespec tspec;
    tspec.tv_sec = 0;
    tspec.tv_nsec = 10000;
    nanosleep(&tspec, NULL);
  }

  return NULL;
}

int main(int argc, char** argv)
{
  // Helper variables
  pthread_attr_t attr;
  void* thread_result;
  int err;

  if ((err = pthread_mutex_init(&Bank::ms_mutex, NULL)) != 0)
  {
    fprintf(stderr, "pthread_mutex_init() error %d\n", err);
    exit(EXIT_FAILURE);
  }

  if ((err = pthread_attr_init(&attr)) != 0)
  {
    fprintf(stderr, "pthread_attr_init() error %d\n", err);
    exit(EXIT_FAILURE);
  }

  if ((err = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE)) != 0)
  {
    fprintf(stderr, "pthread_attr_setdetachstate() error %d\n", err);
    exit(EXIT_FAILURE);
  }

  Bank::ms_bankTotal = 0;

  for (int i = 0; i < ACCOUNTS; i++)
  {
    if (i < (ACCOUNTS / 2))
      Bank::ms_accounts[i] = Account(i, true);
    else
      Bank::ms_accounts[i] = Account(i, WITHOUT_DATARACE);
  }

  std::cout << "Bank week started." << std::endl;

  for (int i = 0; i < ACCOUNTS; i++)
  {
    std::cout << "i: " << i << " " << Bank::ms_accounts[i] << std::endl;

    while ((err = pthread_create(&Bank::ms_threads[i], &attr, tmain,
      (void *)&Bank::ms_accounts[i])) != 0)
    {
      if (err != EAGAIN)
      {
        fprintf(stderr, "pthread_create() error %d\n", err);
        exit(EXIT_FAILURE);
      }
    }
  }

  if ((err = pthread_attr_destroy(&attr)) != 0)
  {
    fprintf(stderr, "pthread_attr_destroy() error %d\n", err);
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < ACCOUNTS; i++)
  {
    if ((err = pthread_join(Bank::ms_threads[i], &thread_result)) != 0)
    {
      fprintf(stderr, "pthread_join() error %d\n", err);
      exit(EXIT_FAILURE);
    }
  }

  std::cout << "End of the week." << std::endl;

  int totalBalance = 0;

  for (int i = 0; i < ACCOUNTS; i++)
  {
    totalBalance += Bank::ms_accounts[i].m_balance;
  }

  std::cout << "Bank records = " << Bank::ms_bankTotal << ", accounts balance = "
    << totalBalance << "." << std::endl;

  if (Bank::ms_bankTotal == totalBalance)
    std::cout << "OK records match" << std::endl;
  else
    std::cout << "ERROR: records don't match !!!" << std::endl;

  if ((err = pthread_mutex_destroy(&Bank::ms_mutex)) != 0)
  {
    fprintf(stderr, "pthread_mutex_destroy() error %d\n", err);
    exit(EXIT_FAILURE);
  }

  exit(EXIT_SUCCESS);
}

/** End of file bank.cpp **/
