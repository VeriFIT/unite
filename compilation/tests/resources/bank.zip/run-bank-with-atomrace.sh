#!/bin/bash
./anaconda.sh "`pwd`/lib/intel64/anaconda-atomrace.so" "`pwd`/bank"