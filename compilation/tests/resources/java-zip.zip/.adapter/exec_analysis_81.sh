/bin/bash -c "$1"
exit $?